"""Stable native submission and local transport interface."""
from importlib import import_module

__all__ = [
    'NativeSender', 'NativeImageDownloader', 'NativeError', 'CHAT_ID',
    'REQUEST_ID', 'MAX_FRAME', 'encode', 'decode', 'receive', 'request',
    'text_parts', 'validate_send', 'IMAGE_DOWNLOAD_ERRORS',
]


def __getattr__(name):
    if name == 'NativeError':
        from wechat_linux.errors import NativeError
        return NativeError
    if name == 'NativeSender':
        from wechat_linux.native.sender import NativeSender
        return NativeSender
    if name == 'NativeImageDownloader':
        from wechat_linux.native.image_download import NativeImageDownloader
        return NativeImageDownloader
    if name == 'IMAGE_DOWNLOAD_ERRORS':
        from wechat_linux.native.image_contract import ERRORS
        return ERRORS
    if name in __all__:
        return getattr(import_module('wechat_linux.native.protocol'), name)
    raise AttributeError(name)
