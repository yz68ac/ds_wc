"""Stable desktop login, image, and compatibility operations."""
from importlib import import_module

__all__ = [
    'LoginController', 'LoginStatus', 'LoginQRCode', 'LoginError',
    'A11y', 'Clipboard', 'Sender', 'UIError', 'WrongChatError', 'X11',
    'chat_label_matches', 'improve_image',
]


def __getattr__(name):
    if name in ('LoginController', 'LoginStatus', 'LoginQRCode', 'LoginError'):
        module = 'login'
    elif name == 'improve_image':
        module = 'image_download'
    elif name in __all__:
        module = 'ui'
    else:
        raise AttributeError(name)
    return getattr(import_module('wechat_linux.desktop.' + module), name)
