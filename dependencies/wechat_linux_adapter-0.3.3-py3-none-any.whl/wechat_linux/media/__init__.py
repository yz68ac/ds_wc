"""Stable image and media operations for adapter consumers."""
from importlib import import_module

__all__ = [
    'MediaError', 'V1', 'V2', 'HEX32', 'image_format', 'validate_image',
    'decode_dat', 'key_candidates', 'read_local_image',
]


def __getattr__(name):
    if name == 'MediaError':
        from wechat_linux.errors import MediaError
        return MediaError
    if name in __all__:
        return getattr(import_module('wechat_linux.media.images'), name)
    raise AttributeError(name)
