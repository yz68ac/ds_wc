"""Stable local database operations for adapter consumers."""
from importlib import import_module

__all__ = [
    'WeChatStore', 'HistoryPage', 'StoreError', 'discover_db_dir',
    'format_time', 'parse_mentioned_users', 'extract_keys', 'AES',
]


def __getattr__(name):
    if name == 'StoreError':
        from wechat_linux.errors import StoreError
        return StoreError
    if name == 'extract_keys':
        return import_module('wechat_linux.storage.keyscan').extract_keys
    if name == 'AES':
        return import_module('wechat_linux.storage.crypto').AES
    if name in __all__:
        return getattr(import_module('wechat_linux.storage.store'), name)
    raise AttributeError(name)
